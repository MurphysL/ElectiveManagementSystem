CREATE VIEW sc_view AS
  SELECT
    `elective`.`class`.`clzno`     AS `clzno`,
    `elective`.`class`.`start`     AS `start`,
    `elective`.`class`.`address`   AS `address`,
    `elective`.`course`.`cno`      AS `cno`,
    `elective`.`course`.`name`     AS `cname`,
    `elective`.`course`.`credit`   AS `credit`,
    `elective`.`course`.`duration` AS `duration`,
    `elective`.`teacher`.`tno`     AS `tno`,
    `elective`.`teacher`.`name`    AS `tname`,
    `elective`.`teacher`.`sex`     AS `tsex`,
    `elective`.`student`.`sno`     AS `sno`,
    `elective`.`student`.`name`    AS `sname`,
    `elective`.`student`.`sex`     AS `ssex`,
    `elective`.`student`.`dept`    AS `dept`,
    `elective`.`student`.`avatar`  AS `avatar`,
    `elective`.`sc`.`grade`        AS `grade`
  FROM ((((`elective`.`class`
    JOIN `elective`.`sc`) JOIN `elective`.`student`) JOIN `elective`.`course`) JOIN `elective`.`teacher`)
  WHERE (
    (`elective`.`class`.`clzno` = `elective`.`sc`.`clzno`) AND (`elective`.`teacher`.`tno` = `elective`.`class`.`tno`)
    AND (`elective`.`sc`.`sno` = `elective`.`student`.`sno`) AND
    (`elective`.`course`.`cno` = `elective`.`class`.`cno`));
