CREATE VIEW sc_view AS
  SELECT
    `clz_view`.`Cno`              AS `Cno`,
    `clz_view`.`Tno`              AS `Tno`,
    `clz_view`.`Time`             AS `Time`,
    `elective`.`student`.`Sno`    AS `Sno`,
    `elective`.`student`.`Sname`  AS `Sname`,
    `elective`.`student`.`Ssex`   AS `Ssex`,
    `elective`.`student`.`Sdept`  AS `Sdept`,
    `elective`.`student`.`avatar` AS `avatar`,
    `elective`.`sc`.`Grade`       AS `Grade`
  FROM ((`elective`.`clz_view`
    JOIN `elective`.`sc`) JOIN `elective`.`student`)
  WHERE ((`clz_view`.`Cno` = `elective`.`sc`.`Cno`) AND (`clz_view`.`Tno` = `elective`.`sc`.`Tno`) AND
         (`elective`.`sc`.`Sno` = `elective`.`student`.`Sno`));
