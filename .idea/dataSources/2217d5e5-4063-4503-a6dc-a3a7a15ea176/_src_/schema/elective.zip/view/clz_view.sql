CREATE VIEW clz_view AS
  SELECT
    `elective`.`course`.`Cno`     AS `Cno`,
    `elective`.`course`.`Cname`   AS `Cname`,
    `elective`.`course`.`Ccredit` AS `Ccredit`,
    `elective`.`teacher`.`Tno`    AS `Tno`,
    `elective`.`teacher`.`Tname`  AS `Tname`,
    `elective`.`teacher`.`Tsex`   AS `Tsex`,
    `elective`.`class`.`Address`  AS `Address`,
    `elective`.`class`.`Time`     AS `Time`
  FROM `elective`.`class`
    JOIN `elective`.`course`
    JOIN `elective`.`teacher`
  WHERE ((`elective`.`class`.`Tno` = `elective`.`teacher`.`Tno`) AND
         (`elective`.`course`.`Cno` = `elective`.`class`.`Cno`));
