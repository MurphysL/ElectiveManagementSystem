CREATE VIEW detail_clz AS
  SELECT
    `elective`.`class`.`clzno`     AS `clzno`,
    `elective`.`class`.`start`     AS `start`,
    `elective`.`class`.`address`   AS `address`,
    `elective`.`course`.`cno`      AS `cno`,
    `elective`.`course`.`name`     AS `cname`,
    `elective`.`course`.`credit`   AS `credit`,
    `elective`.`course`.`duration` AS `duration`,
    `elective`.`teacher`.`tno`     AS `tno`,
    `elective`.`teacher`.`name`    AS `tname`,
    `elective`.`teacher`.`sex`     AS `sex`
  FROM ((`elective`.`class`
    JOIN `elective`.`course`) JOIN `elective`.`teacher`)
  WHERE ((`elective`.`class`.`tno` = `elective`.`teacher`.`tno`) AND
         (`elective`.`course`.`cno` = `elective`.`class`.`cno`));
